// Without virtual, the diamond holds TWO Person sub-objects: the name is ambiguous.
#include <string>
struct Person { std::string name = "x"; };
struct Student : Person {};
struct Staff : Person {};
struct TeachingAssistant : Student, Staff {};
int main() { TeachingAssistant ta; return static_cast<int>(ta.name.size()); }
