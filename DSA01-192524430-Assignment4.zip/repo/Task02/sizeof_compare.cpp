// Task 2 alternative: virtual diamond vs composition (has-a) vs non-virtual diamond
#include <chrono>
#include <iostream>
#include <string>
struct Person { std::string name; int id; std::string phone; };

struct VStudent : virtual Person { std::string programme; double cgpa; };
struct VStaff   : virtual Person { std::string dept; double salary; };
struct TA_virtual : VStudent, VStaff {};

struct NStudent : Person { std::string programme; double cgpa; };
struct NStaff   : Person { std::string dept; double salary; };
struct TA_plain : NStudent, NStaff {};              // two Person sub-objects

struct TA_has { NStudent student; NStaff staff; };   // composition: two Person copies too

int main()
{
    std::cout << "sizeof(Person)               = " << sizeof(Person) << '\n'
              << "sizeof(TA_virtual)  (1 Person + vbptrs) = " << sizeof(TA_virtual) << '\n'
              << "sizeof(TA_plain)    (2 Person)          = " << sizeof(TA_plain) << '\n'
              << "sizeof(TA_has)      (2 Person, has-a)   = " << sizeof(TA_has) << '\n';

    TA_virtual v; TA_has h; v.name = "Arun";
    h.student.name = "Arun"; h.staff.name = "Arun";
    constexpr int N = 200000000;
    volatile std::size_t sink = 0;
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < N; ++i) sink = sink + v.name.size();     // via virtual base
    auto t1 = std::chrono::steady_clock::now();
    for (int i = 0; i < N; ++i) sink = sink + h.student.name.size();   // direct member
    auto t2 = std::chrono::steady_clock::now();
    std::cout << "access v.name (virtual base): "
              << std::chrono::duration<double, std::nano>(t1 - t0).count() / N << " ns\n"
              << "access h.student.name (member): "
              << std::chrono::duration<double, std::nano>(t2 - t1).count() / N << " ns\n";
}
