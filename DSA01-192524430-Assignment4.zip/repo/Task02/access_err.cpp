// Task 2.4 - what the compiler says about Person's members under each inheritance type
struct Person { int pub = 1; protected: int prot = 2; private: int priv = 3; };

struct DPub  : public    Person { int inside() { return pub + prot; } int tryPriv() { return priv; } };
struct DProt : protected Person { int inside() { return pub + prot; } };
struct DPriv : private   Person { int inside() { return pub + prot; } };

struct GPub  : DPub  { int inside() { return pub + prot; } };   // grandchild
struct GProt : DProt { int inside() { return pub + prot; } };   // grandchild
struct GPriv : DPriv { int inside() { return pub + prot; } };   // grandchild

int main()
{
    DPub a; DProt b; DPriv c;
    int x = a.pub;     // outside access via public inheritance
    int y = b.pub;     // outside access via protected inheritance
    int z = c.pub;     // outside access via private inheritance
    return x + y + z;
}
