// Task 2.3 - University people hierarchy (virtual base resolves the diamond)
#include <iostream>
#include <string>

class Person {                                   // common base
protected:
    std::string name_;
    int id_;
    std::string phone_;
public:
    Person(const std::string& n, int id, const std::string& ph) : name_(n), id_(id), phone_(ph) {}
    virtual ~Person() = default;
    virtual void show() const { std::cout << id_ << ' ' << name_ << ' ' << phone_; }
};

class Student : virtual public Person {          // is-a Person (public: interface preserved)
protected:
    std::string programme_;
    double cgpa_;
public:
    Student(const std::string& n, int id, const std::string& ph, const std::string& prog, double g)
        : Person(n, id, ph), programme_(prog), cgpa_(g) {}
    void show() const override
    { Person::show(); std::cout << " | " << programme_ << " CGPA " << cgpa_; }
};

class Staff : virtual public Person {            // is-a Person
protected:
    std::string dept_;
    double salary_;
public:
    Staff(const std::string& n, int id, const std::string& ph, const std::string& d, double s)
        : Person(n, id, ph), dept_(d), salary_(s) {}
    void show() const override
    { Person::show(); std::cout << " | " << dept_ << " Rs." << salary_; }
};

class TeachingAssistant : public Student, public Staff {   // multiple -> diamond (hybrid)
public:
    TeachingAssistant(const std::string& n, int id, const std::string& ph, const std::string& prog,
                      double g, const std::string& d, double s)
        : Person(n, id, ph),                     // most-derived class builds the virtual base
          Student(n, id, ph, prog, g), Staff(n, id, ph, d, s) {}
    void show() const override
    {
        Person::show();                          // ONE Person -> no ambiguity
        std::cout << " | " << programme_ << " CGPA " << cgpa_ << " | " << dept_ << " Rs." << salary_;
    }
};

class Fellowship {                               // has-a: member class
    std::string agency_;
    double amount_;
public:
    Fellowship(const std::string& a, double m) : agency_(a), amount_(m) {}
    void show() const { std::cout << agency_ << " Rs." << amount_; }
};

class ResearchScholar : public Student {         // is-a Student (single, multilevel from Person)
    Fellowship fellowship_;                      // has-a Fellowship
public:
    ResearchScholar(const std::string& n, int id, const std::string& ph, const std::string& prog,
                    double g, const std::string& agency, double amt)
        : Person(n, id, ph), Student(n, id, ph, prog, g), fellowship_(agency, amt) {}
    void show() const override
    { Student::show(); std::cout << " | Fellowship: "; fellowship_.show(); }
};

int main()
{
    Student s("Kavya", 1, "9000000001", "B.Tech", 8.7);
    Staff f("Dr. Rao", 2, "9000000002", "CSE", 90000);
    TeachingAssistant ta("Arun", 3, "9000000003", "M.Tech", 9.1, "CSE", 25000);
    ResearchScholar rs("Divya", 4, "9000000004", "PhD", 9.4, "UGC-JRF", 31000);
    const Person* all[] = {&s, &f, &ta, &rs};
    for (const Person* p : all) { p->show(); std::cout << '\n'; }
}
