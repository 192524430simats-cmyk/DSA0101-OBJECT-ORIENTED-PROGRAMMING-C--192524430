// Task 1 alternative: ONE Staff class with a type field and a switch in pay()
#include <chrono>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

enum class Kind { Professor, LabAssistant, GuestFaculty };

struct StaffS {                       // every object carries EVERY field
    Kind kind;
    std::string name;
    int id;
    double basic;                     // unused by GuestFaculty
    double research;                  // used only by Professor
    double hours;                     // used only by GuestFaculty
    double rate;                      // used only by GuestFaculty
    double pay() const
    {
        switch (kind) {
        case Kind::Professor:    return basic + basic * 0.42 + research;
        case Kind::LabAssistant: return basic + basic * 0.42;
        case Kind::GuestFaculty: return hours * rate;
        }
        return 0;                     // a NEW kind needs a new case HERE
    }
};

int main()
{
    std::vector<StaffS> all = {
        {Kind::Professor, "Dr. Meena", 101, 80000, 15000, 0, 0},
        {Kind::LabAssistant, "Ravi", 102, 30000, 0, 0, 0},
        {Kind::GuestFaculty, "Anitha", 103, 0, 0, 40, 1200}};
    std::cout << std::fixed << std::setprecision(2);
    double total = 0;
    for (const auto& s : all) { std::cout << s.name << ' ' << s.pay() << '\n'; total += s.pay(); }
    std::cout << "Total payroll: " << total << "\n\n";
    std::cout << "sizeof(StaffS)=" << sizeof(StaffS) << " bytes (same for every kind)\n";

    std::vector<StaffS> big;
    for (int i = 0; i < 1000000; ++i)
        big.push_back(StaffS{static_cast<Kind>(i % 3), "P", i, 80000, 15000, 40, 1200});
    volatile double sink = 0; (void)sink;
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 20; ++r) { double s = 0; for (auto& p : big) s += p.pay(); sink = s; }
    auto t1 = std::chrono::steady_clock::now();
    double ns = std::chrono::duration<double, std::nano>(t1 - t0).count() / (20.0 * 1000000);
    std::cout << "switch pay():  " << ns << " ns per call (-O2)\n";
}
