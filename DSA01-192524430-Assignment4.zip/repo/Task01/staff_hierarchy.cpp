// Task 1.2 - Repaired payroll design: common base class + derived classes
#include <chrono>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <utility>
#include <vector>

class Staff {                              // abstract base: data common to all staff
    std::string name_;
    int id_;
public:
    Staff(std::string name, int id) : name_(std::move(name)), id_(id) {}
    virtual ~Staff() = default;
    virtual double pay() const = 0;        // every category supplies its own rule
    virtual std::string category() const = 0;
    const std::string& name() const { return name_; }
    int id() const { return id_; }
};

class SalariedStaff : public Staff {       // shared rule: basic + dearness allowance
protected:
    static constexpr double DA_RATE = 0.42;   // named constant replaces magic 0.42
    double basic_;
    double basicWithDA() const { return basic_ + basic_ * DA_RATE; }
public:
    SalariedStaff(std::string n, int id, double basic)
        : Staff(std::move(n), id), basic_(basic) {}
};

class Professor : public SalariedStaff {
    double research_;
public:
    Professor(std::string n, int id, double basic, double research)
        : SalariedStaff(std::move(n), id, basic), research_(research) {}
    double pay() const override { return basicWithDA() + research_; }
    std::string category() const override { return "Professor"; }
};

class LabAssistant : public SalariedStaff {
public:
    LabAssistant(std::string n, int id, double basic)
        : SalariedStaff(std::move(n), id, basic) {}
    double pay() const override { return basicWithDA(); }
    std::string category() const override { return "LabAssistant"; }
};

class GuestFaculty : public Staff {
    double hours_, rate_;
public:
    GuestFaculty(std::string n, int id, double hours, double rate)
        : Staff(std::move(n), id), hours_(hours), rate_(rate) {}
    double pay() const override { return hours_ * rate_; }
    std::string category() const override { return "GuestFaculty"; }
};

// ---- NEW CATEGORY: added later in a new class; no existing class is edited ----
class TechnicalStaff : public SalariedStaff {
    double allowance_;
public:
    TechnicalStaff(std::string n, int id, double basic, double allowance)
        : SalariedStaff(std::move(n), id, basic), allowance_(allowance) {}
    double pay() const override { return basicWithDA() + allowance_; }
    std::string category() const override { return "TechnicalStaff"; }
};

int main()
{
    std::vector<std::unique_ptr<Staff>> all;           // one container for all staff
    all.push_back(std::make_unique<Professor>("Dr. Meena", 101, 80000, 15000));
    all.push_back(std::make_unique<LabAssistant>("Ravi", 102, 30000));
    all.push_back(std::make_unique<GuestFaculty>("Anitha", 103, 40, 1200));
    all.push_back(std::make_unique<TechnicalStaff>("Karthik", 104, 45000, 5000));

    std::cout << std::fixed << std::setprecision(2);
    double total = 0;
    for (const auto& s : all) {                         // ONE loop, polymorphic pay()
        std::cout << std::left << std::setw(15) << s->category() << std::setw(10)
                  << s->name() << std::right << std::setw(12) << s->pay() << '\n';
        total += s->pay();
    }
    std::cout << "Total payroll: " << total << "\n\n";

    std::cout << "sizeof(Professor)=" << sizeof(Professor)
              << " sizeof(LabAssistant)=" << sizeof(LabAssistant)
              << " sizeof(GuestFaculty)=" << sizeof(GuestFaculty) << '\n';

    // timing: 1,000,000 staff objects, 20 passes of pay()
    std::vector<std::unique_ptr<Staff>> big;
    for (int i = 0; i < 1000000; ++i) {
        if (i % 3 == 0) big.push_back(std::make_unique<Professor>("P", i, 80000, 15000));
        else if (i % 3 == 1) big.push_back(std::make_unique<LabAssistant>("L", i, 30000));
        else big.push_back(std::make_unique<GuestFaculty>("G", i, 40, 1200));
    }
    volatile double sink = 0; (void)sink;
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 20; ++r) { double s = 0; for (auto& p : big) s += p->pay(); sink = s; }
    auto t1 = std::chrono::steady_clock::now();
    double ns = std::chrono::duration<double, std::nano>(t1 - t0).count() / (20.0 * 1000000);
    std::cout << "virtual pay(): " << ns << " ns per call (-O2)\n";
}
