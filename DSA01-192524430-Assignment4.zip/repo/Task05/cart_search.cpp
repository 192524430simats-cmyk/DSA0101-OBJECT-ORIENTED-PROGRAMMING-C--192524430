// Task 5.2 - array of pointers to Cart: find the cart with the highest total
#include <iomanip>
#include <iostream>
#include <string>

class Cart {
    std::string owner;
    double sum = 0;
public:
    Cart(const std::string& o, double s) : owner(o), sum(s) {}
    double total() const { return sum; }
    const std::string& who() const { return owner; }
};

Cart* richest(Cart* carts[], int n)                 // indexing version
{
    Cart* best = carts[0];
    for (int i = 1; i < n; ++i) if (carts[i]->total() > best->total()) best = carts[i];
    return best;
}
Cart* richestPtr(Cart** first, Cart** last)         // pointer-arithmetic version
{
    Cart* best = *first;
    for (Cart** p = first + 1; p != last; ++p) if ((*p)->total() > best->total()) best = *p;
    return best;
}

int main()
{
    Cart* active[4] = { new Cart("Arun", 340.5), new Cart("Divya", 810.0),
                        new Cart("Kavya", 275.0), new Cart("Ravi", 640.25) };
    std::cout << std::fixed << std::setprecision(2);
    Cart* b1 = richest(active, 4);
    Cart* b2 = richestPtr(active, active + 4);
    std::cout << "indexing : " << b1->who() << " " << b1->total() << '\n';
    std::cout << "pointers : " << b2->who() << " " << b2->total() << '\n';
    for (Cart* c : active) delete c;
}
