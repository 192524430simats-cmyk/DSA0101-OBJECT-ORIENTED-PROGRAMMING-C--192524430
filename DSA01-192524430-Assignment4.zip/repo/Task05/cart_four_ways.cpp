// Task 5.1 - four ways to reach a Cart + this pointer + chaining
#include <iomanip>
#include <iostream>
#include <string>

class Cart {
    std::string owner;
    std::string items[10];
    double prices[10];
    int n = 0;
    double discount = 0;                       // percent
public:
    Cart& setOwner(const std::string& owner)   // parameter has the SAME name as the member
    { this->owner = owner; return *this; }     // this-> picks the member
    Cart& add(const std::string& item, double price)
    { if (n < 10) { items[n] = item; prices[n] = price; ++n; } return *this; }   // chain
    Cart& setDiscount(double discount) { this->discount = discount; return *this; }
    double total() const
    { double t = 0; for (int i = 0; i < n; ++i) t += prices[i]; return t * (100 - discount) / 100; }
    const std::string& who() const { return owner; }
    const Cart* address() const { return this; }   // 'this' is a pointer to the current object
};

void viaReference(Cart& r) { r.add("Milk", 30); }          // (c) through a reference

int main()
{
    std::cout << std::fixed << std::setprecision(2);

    Cart a;                                                 // (a) directly by name
    a.setOwner("Arun").add("Rice", 60).add("Dal", 120).setDiscount(10);
    std::cout << "(a) by name      : " << a.who() << " total " << a.total() << '\n';

    Cart b;
    Cart* pb = &b;                                          // (b) through a pointer with ->
    pb->setOwner("Divya").add("Oil", 180);
    std::cout << "(b) pointer ->   : " << pb->who() << " total " << pb->total() << '\n';

    Cart c;
    viaReference(c);                                        // (c) through a reference
    Cart& rc = c;
    rc.setOwner("Kavya").add("Tea", 250);
    std::cout << "(c) reference    : " << c.who() << " total " << c.total() << '\n';

    Cart* d = new Cart;                                     // (d) new ... delete
    d->setOwner("Ravi").add("Sugar", 45).add("Salt", 20);
    std::cout << "(d) new/delete   : " << d->who() << " total " << d->total() << '\n';
    std::cout << "this == &object : " << std::boolalpha << (d->address() == d) << '\n';
    delete d;                                               // released by the programmer
    d = nullptr;                                            // avoid a dangling pointer
}
