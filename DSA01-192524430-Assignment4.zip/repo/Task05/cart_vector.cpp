// Task 5 alternative: std::vector<Cart> (objects) instead of an array of Cart*
#include <chrono>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
class Cart {
    std::string items[10];
    double prices[10];
    int n = 0;
public:
    explicit Cart(double base) { for (int i = 0; i < 3; ++i) { items[n] = "x"; prices[n++] = base + i; } }
    double total() const { double t = 0; for (int i = 0; i < n; ++i) t += prices[i]; return t; }
};
int main()
{
    std::cout << "sizeof(Cart) = " << sizeof(Cart) << ", sizeof(Cart*) = " << sizeof(Cart*) << '\n';

    std::vector<Cart> v; v.reserve(2);
    v.emplace_back(1.0); v.emplace_back(2.0);
    const Cart* p = &v[0];
    std::uintptr_t before = reinterpret_cast<std::uintptr_t>(p);
    v.emplace_back(3.0);                              // capacity exceeded -> reallocation
    std::uintptr_t after = reinterpret_cast<std::uintptr_t>(&v[0]);
    std::cout << "address of v[0] before growth: 0x" << std::hex << before << '\n'
              << "address of v[0] after  growth: 0x" << after << std::dec << '\n'
              << "old pointer still valid? " << (before == after ? "yes" : "NO - dangling") << '\n';

    const int N = 100000;
    std::vector<Cart> objs; objs.reserve(N);
    std::vector<Cart*> ptrs;
    for (int i = 0; i < N; ++i) { objs.emplace_back(i % 977); ptrs.push_back(new Cart(i % 977)); }
    volatile double sink = 0; (void)sink;
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 200; ++r) { double best = -1; for (auto& c : objs) if (c.total() > best) best = c.total(); sink = best; }
    auto t1 = std::chrono::steady_clock::now();
    for (int r = 0; r < 200; ++r) { double best = -1; for (auto* c : ptrs) if (c->total() > best) best = c->total(); sink = best; }
    auto t2 = std::chrono::steady_clock::now();
    std::cout << "max-search over " << N << " carts: vector<Cart> "
              << std::chrono::duration<double, std::milli>(t1 - t0).count() / 200 << " ms, Cart*[] "
              << std::chrono::duration<double, std::milli>(t2 - t1).count() / 200 << " ms\n";
    for (auto* c : ptrs) delete c;
}
