// ebus.h - a NEW vehicle type added later. vehicle.h is NOT modified.
#pragma once
#include "vehicle.h"

class ElectricBus : public MotorVehicle {
    int seats_;
    double batteryKWh_;
public:
    static constexpr double ENERGY_PRICE = 10.5;       // bulk tariff, Rs per kWh
    ElectricBus(std::string reg, double rate, int level, ServiceDate due, int seats, double kwh)
        : MotorVehicle(std::move(reg), rate, level, due), seats_(seats), batteryKWh_(kwh) {}
    std::string type() const override { return "ElectricBus"; }
    std::string levelName() const override { return "Charge"; }
    double charge(int days, double kWhUsed) const override
    { return days * dailyRate() + kWhUsed * ENERGY_PRICE; }
    void print() const override
    { MotorVehicle::print(); std::cout << "  seats " << seats_ << "  battery " << batteryKWh_ << " kWh"; }
};
