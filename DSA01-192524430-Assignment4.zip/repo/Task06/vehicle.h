// vehicle.h - Vehicle rental fleet: abstract base + derived classes + member class
#pragma once
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>

class ServiceDate {                                   // member class (has-a)
    int d_, m_, y_;
public:
    ServiceDate(int d, int m, int y) : d_(d), m_(m), y_(y) {}
    std::string str() const
    { char b[16]; std::snprintf(b, sizeof b, "%02d-%02d-%04d", d_, m_, y_); return b; }
};

class Vehicle {                                       // ABSTRACT base class
    std::string reg_;
    double dailyRate_;
    bool rented_ = false;
public:
    static constexpr double LATE_FACTOR = 1.5;        // late day costs 1.5 x daily rate
    Vehicle(std::string reg, double rate) : reg_(std::move(reg)), dailyRate_(rate) {}
    Vehicle(const Vehicle&) = delete;                 // fleet objects are never copied/sliced
    Vehicle& operator=(const Vehicle&) = delete;
    virtual ~Vehicle() = default;                     // virtual destructor

    virtual std::string type() const = 0;                         // pure virtual
    virtual double charge(int days, double usage) const = 0;      // pure virtual: rental charge
    virtual void print() const
    { std::cout << std::left << std::setw(14) << type() << std::setw(15) << reg_
                << "Rs." << std::setw(10) << dailyRate_ << (rented_ ? "RENTED   " : "available "); }

    const std::string& reg() const { return reg_; }
    double dailyRate() const { return dailyRate_; }
    bool isRented() const { return rented_; }

    bool rent() { if (rented_) return false; rented_ = true; return true; }
    double giveBack(int days, int lateDays, double usage)         // returns total bill, -1 if not rented
    {
        if (!rented_) return -1;
        rented_ = false;
        return charge(days, usage) + lateDays * dailyRate_ * LATE_FACTOR;
    }
};

class Bicycle : public Vehicle {
public:
    using Vehicle::Vehicle;
    std::string type() const override { return "Bicycle"; }
    double charge(int days, double) const override { return days * dailyRate(); }
};

class MotorVehicle : public Vehicle {                 // still abstract (charge not defined)
protected:
    int level_;                                        // fuel % or charge %
    ServiceDate serviceDue_;                           // has-a ServiceDate
public:
    static constexpr double FUEL_PRICE = 105.0;        // Rs per litre
    MotorVehicle(std::string reg, double rate, int level, ServiceDate due)
        : Vehicle(std::move(reg), rate), level_(level), serviceDue_(due) {}
    virtual std::string levelName() const { return "Fuel"; }
    void print() const override
    { Vehicle::print(); std::cout << levelName() << ' ' << level_ << "%  service due " << serviceDue_.str(); }
};

class TwoWheeler : public MotorVehicle {
public:
    using MotorVehicle::MotorVehicle;
    std::string type() const override { return "TwoWheeler"; }
    double charge(int days, double litres) const override { return days * dailyRate() + litres * FUEL_PRICE; }
};

class Car : public MotorVehicle {
protected:
    int seats_;
    double seatSurcharge(int days) const { return seats_ > 5 ? (seats_ - 5) * 50.0 * days : 0.0; }
public:
    Car(std::string reg, double rate, int level, ServiceDate due, int seats)
        : MotorVehicle(std::move(reg), rate, level, due), seats_(seats) {}
    std::string type() const override { return "Car"; }
    double charge(int days, double litres) const override
    { return days * dailyRate() + seatSurcharge(days) + litres * FUEL_PRICE; }
    void print() const override { MotorVehicle::print(); std::cout << "  seats " << seats_; }
};

class ElectricCar : public Car {                      // multilevel: ... -> Car -> ElectricCar
    double batteryKWh_;
public:
    static constexpr double ENERGY_PRICE = 12.0;       // Rs per kWh
    ElectricCar(std::string reg, double rate, int level, ServiceDate due, int seats, double kwh)
        : Car(std::move(reg), rate, level, due, seats), batteryKWh_(kwh) {}
    std::string type() const override { return "ElectricCar"; }
    std::string levelName() const override { return "Charge"; }
    double charge(int days, double kWhUsed) const override      // per kWh, not per litre
    { return days * dailyRate() + seatSurcharge(days) + kWhUsed * ENERGY_PRICE; }
    void print() const override { Car::print(); std::cout << "  battery " << batteryKWh_ << " kWh"; }
};

// ---------------- fleet helpers: the fleet is an array of base-class pointers ----------------
inline Vehicle* findVehicle(Vehicle* fleet[], int n, const std::string& reg)
{ for (int i = 0; i < n; ++i) if (fleet[i]->reg() == reg) return fleet[i]; return nullptr; }

inline bool rentVehicle(Vehicle* fleet[], int n, const std::string& reg)
{ Vehicle* v = findVehicle(fleet, n, reg); return v && v->rent(); }

inline double returnVehicle(Vehicle* fleet[], int n, const std::string& reg, int days, int late, double usage)
{ Vehicle* v = findVehicle(fleet, n, reg); return v ? v->giveBack(days, late, usage) : -2; }

inline void listFleet(Vehicle* fleet[], int n)
{ for (int i = 0; i < n; ++i) { fleet[i]->print(); std::cout << '\n'; } }
