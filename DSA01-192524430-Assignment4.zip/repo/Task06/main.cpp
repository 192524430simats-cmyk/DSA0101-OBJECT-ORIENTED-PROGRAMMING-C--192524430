// main.cpp - Task 6 Stage 5: rent, return with late charge, add a new type, check requirements
#include <cmath>
#include "ebus.h"
#include "vehicle.h"

static int passed = 0, total = 0;
static void check(const char* id, bool ok)
{ ++total; passed += ok; std::cout << "  [" << (ok ? "PASS" : "FAIL") << "] " << id << '\n'; }
static bool near(double a, double b) { return std::fabs(a - b) < 1e-9; }

int main()
{
    std::cout << std::fixed << std::setprecision(2);
    const int CAP = 8;
    Vehicle* fleet[CAP];
    int n = 0;
    fleet[n++] = new Bicycle("B-101", 150);
    fleet[n++] = new TwoWheeler("TN33-AB-1234", 400, 80, ServiceDate(15, 12, 2026));
    fleet[n++] = new Car("TN33-CD-5678", 1500, 60, ServiceDate(10, 1, 2027), 7);
    fleet[n++] = new ElectricCar("TN34-EV-0001", 2000, 90, ServiceDate(20, 2, 2027), 5, 60.0);

    std::cout << "=== Fleet (4 types) ===\n";
    listFleet(fleet, n);

    std::cout << "\n=== Renting each type ===\n";
    for (int i = 0; i < n; ++i)
        std::cout << fleet[i]->reg() << " rent -> " << (rentVehicle(fleet, n, fleet[i]->reg()) ? "OK" : "refused") << '\n';
    bool again = rentVehicle(fleet, n, "TN33-CD-5678");
    std::cout << "TN33-CD-5678 rent again -> " << (again ? "OK" : "refused (already rented)") << '\n';

    std::cout << "\n=== Returning ===\n";
    double b1 = returnVehicle(fleet, n, "B-101", 3, 1, 0);
    double b2 = returnVehicle(fleet, n, "TN33-AB-1234", 2, 0, 5);
    double b3 = returnVehicle(fleet, n, "TN33-CD-5678", 4, 2, 30);
    double b4 = returnVehicle(fleet, n, "TN34-EV-0001", 3, 0, 18);
    std::cout << "B-101         3 days, 1 late day            : Rs." << b1 << '\n'
              << "TN33-AB-1234  2 days, 5 L fuel              : Rs." << b2 << '\n'
              << "TN33-CD-5678  4 days, 2 late days, 30 L     : Rs." << b3 << '\n'
              << "TN34-EV-0001  3 days, 18 kWh                : Rs." << b4 << '\n';

    std::cout << "\n=== Adding a NEW type (ElectricBus) - no existing class changed ===\n";
    fleet[n++] = new ElectricBus("TN30-EB-0100", 6000, 95, ServiceDate(1, 3, 2027), 30, 120.0);
    listFleet(fleet, n);
    rentVehicle(fleet, n, "TN30-EB-0100");
    double b5 = returnVehicle(fleet, n, "TN30-EB-0100", 1, 1, 80);
    std::cout << "TN30-EB-0100  1 day, 1 late day, 80 kWh     : Rs." << b5 << '\n';

    std::cout << "\n=== Requirement checks ===\n";
    check("R1 bicycle: 3 days + 1 late day = 675", near(b1, 675));
    check("R2 two-wheeler: fuel charged per litre = 1325", near(b2, 1325));
    check("R3 7-seat car: seat surcharge + fuel + late = 14050", near(b3, 14050));
    check("R4 electric car: per kWh, no fuel price = 6216", near(b4, 6216));
    check("R5 renting an already rented vehicle is refused", !again);
    check("R6 returning a vehicle that is not rented gives -1", near(returnVehicle(fleet, n, "B-101", 1, 0, 0), -1));
    check("R7 new ElectricBus works through Vehicle* with no edits = 15840", near(b5, 15840));
    check("R8 all vehicles available after returns", !fleet[0]->isRented() && !fleet[4]->isRented());
    std::cout << passed << "/" << total << " checks passed\n";

    std::cout << "\nsizeof: Bicycle=" << sizeof(Bicycle) << " TwoWheeler=" << sizeof(TwoWheeler)
              << " Car=" << sizeof(Car) << " ElectricCar=" << sizeof(ElectricCar)
              << " ElectricBus=" << sizeof(ElectricBus) << '\n';
    for (int i = 0; i < n; ++i) delete fleet[i];          // virtual destructor -> full cleanup
}
