// virtual charge() timing (hierarchy) - compare with vehicle_switch.cpp
#include <chrono>
#include "ebus.h"
#include "vehicle.h"
int main()
{
    const int N = 1000;
    Vehicle* fleet[N];
    for (int i = 0; i < N; ++i) {
        switch (i % 4) {
        case 0: fleet[i] = new Bicycle("B", 150); break;
        case 1: fleet[i] = new TwoWheeler("T", 400, 80, ServiceDate(1, 1, 2027)); break;
        case 2: fleet[i] = new Car("C", 1500, 60, ServiceDate(1, 1, 2027), 7); break;
        default: fleet[i] = new ElectricCar("E", 2000, 90, ServiceDate(1, 1, 2027), 5, 60); }
    }
    volatile double sink = 0; (void)sink;
    const int R = 100000;
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < R; ++r) { double s = 0; for (int i = 0; i < N; ++i) s += fleet[i]->charge(3, 10); sink = s; }
    auto t1 = std::chrono::steady_clock::now();
    std::cout << "virtual charge(): " << std::chrono::duration<double, std::nano>(t1 - t0).count() / (double(R) * N)
              << " ns per call (-O2)\n";
    for (int i = 0; i < N; ++i) delete fleet[i];
}
