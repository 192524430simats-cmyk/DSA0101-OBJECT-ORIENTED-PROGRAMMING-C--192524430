// Task 6 alternative: ONE Vehicle class, type code + switch in charge()
#include <chrono>
#include <iostream>
#include <string>

enum class VType { Bicycle, TwoWheeler, Car, ElectricCar };
struct ServiceDate { int d, m, y; };

struct VehicleS {                         // every object carries every field
    VType type;
    std::string reg;
    double dailyRate;
    bool rented;
    int level;                            // unused by Bicycle
    ServiceDate serviceDue;               // unused by Bicycle
    int seats;                            // used by Car / ElectricCar only
    double batteryKWh;                    // used by ElectricCar only
    double charge(int days, double usage) const
    {
        switch (type) {
        case VType::Bicycle:    return days * dailyRate;
        case VType::TwoWheeler: return days * dailyRate + usage * 105.0;
        case VType::Car:        return days * dailyRate + (seats > 5 ? (seats - 5) * 50.0 * days : 0) + usage * 105.0;
        case VType::ElectricCar:return days * dailyRate + (seats > 5 ? (seats - 5) * 50.0 * days : 0) + usage * 12.0;
        }
        return 0;                         // a new type = a new case here (existing code edited)
    }
};

int main()
{
    std::cout << "sizeof(VehicleS) = " << sizeof(VehicleS) << " bytes for EVERY vehicle type\n";
    const int N = 1000;
    static VehicleS fleet[N];
    for (int i = 0; i < N; ++i)
        fleet[i] = VehicleS{static_cast<VType>(i % 4), "X", 1500, false, 60, {1, 1, 2027}, 7, 60};
    volatile double sink = 0; (void)sink;
    const int R = 100000;
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < R; ++r) { double s = 0; for (int i = 0; i < N; ++i) s += fleet[i].charge(3, 10); sink = s; }
    auto t1 = std::chrono::steady_clock::now();
    std::cout << "switch charge():  " << std::chrono::duration<double, std::nano>(t1 - t0).count() / (double(R) * N)
              << " ns per call (-O2)\n";
}
