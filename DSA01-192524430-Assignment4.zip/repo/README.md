# DSA01-192524430-Assignment4

- **Name:** Mohamed Haarun M.H
- **Register number:** 192524430
- **Course:** Object Oriented Programming with C++ (DSA01) - Assignment 4 (CO4)
- **Compiler:** g++ (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0
- **Compile command:** `g++ -std=c++17 -Wall -Wextra FILE.cpp -o prog`
  (timing programs add `-O2`; Task 3.4 adds `-DNOVIRT`; Task 4 sanitizer runs add `-g -fsanitize=address`)

## How to run
```
cd TaskNN
g++ -std=c++17 -Wall -Wextra FILE.cpp -o prog && ./prog
```
Task 6: `cd Task06 && g++ -std=c++17 -Wall -Wextra main.cpp -o fleet && ./fleet` (headers vehicle.h and ebus.h in the same folder).

## Result of each task
| Task | Programs | Result |
|------|----------|--------|
| 1 | staff_hierarchy.cpp, staff_switch.cpp | One loop pays all staff (total 288,100.00); TechnicalStaff added without editing existing classes |
| 2 | ta_predict, ta_novirtual, university, access_err, ambig, sizeof_compare | Prediction `Person Student Staff TA`; without virtual Person printed twice; sizeof 168 B (virtual) vs 224 B |
| 3 | trace (+ -DNOVIRT), engine_predict, student_init (+ swapped), student_ptr | Order: bases -> members -> body, destruction reversed; TA 216 B vs 288 B; -Wreorder reproduced |
| 4 | defects, repaired, repaired_slice_err, predict, uptr | Non-virtual rate, non-virtual destructor (800 B leak) and slicing proven; repaired version clean under ASan/LSan; output `3.5 4 3.5` |
| 5 | cart_four_ways, cart_search, cart_complete, cart_byvalue, cart_vector | `324.00` as expected; returning Cart by value gives `240.00` |
| 6 | main.cpp (+ vehicle.h, ebus.h), bench.cpp, vehicle_switch.cpp | 8/8 requirement checks pass; ElectricBus added with no change to vehicle.h |

Each task folder contains the sources, output screenshots (PNG) and UML diagrams. The full report is `DSA01_Assignment4_192524430.pdf`.
