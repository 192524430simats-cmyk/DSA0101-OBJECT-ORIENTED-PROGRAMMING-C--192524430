// Task 3 alternative: Student holds Address* (heap) instead of an Address member object
#include <chrono>
#include <iostream>
#include <string>
#include <vector>

class Address {
    std::string city; int pin;
public:
    static int live;                                   // counts live Address objects
    Address(const std::string& c, int p) : city(c), pin(p) { ++live; }
    Address(const Address& o) : city(o.city), pin(o.pin) { ++live; }
    ~Address() { --live; }
    std::string str() const { return city + "-" + std::to_string(pin); }
};
int Address::live = 0;

class StudentM {                                       // member-object version
    long long regNo; Address home;
public:
    StudentM(long long r, const std::string& c, int p) : regNo(r), home(c, p) {}
    long long reg() const { return regNo; }
};

class StudentP {                                       // pointer version: Rule of Three
    long long regNo; Address* home;
public:
    StudentP(long long r, const std::string& c, int p) : regNo(r), home(new Address(c, p)) {}
    StudentP(const StudentP& o) : regNo(o.regNo), home(new Address(*o.home)) {}   // deep copy
    StudentP& operator=(const StudentP& o)
    {
        if (this != &o) { Address* t = new Address(*o.home); delete home; home = t; regNo = o.regNo; }
        return *this;
    }
    ~StudentP() { delete home; }                       // must release the heap Address
    long long reg() const { return regNo; }
    std::string where() const { return home->str(); }
};

int main()
{
    {
        StudentP a(1, "Salem", 636001);
        StudentP b = a;                                // deep copy
        StudentP c(2, "Erode", 638001);
        c = a;                                         // deep assignment
        std::cout << "live Address objects inside block: " << Address::live << '\n';
        std::cout << b.where() << ' ' << c.where() << '\n';
    }
    std::cout << "live Address objects after block:  " << Address::live << " (no leak)\n";
    std::cout << "sizeof(StudentM)=" << sizeof(StudentM) << "  sizeof(StudentP)=" << sizeof(StudentP)
              << "  (+ sizeof(Address)=" << sizeof(Address) << " on the heap)\n";

    const int N = 1000000;
    auto t0 = std::chrono::steady_clock::now();
    { std::vector<StudentM> v; v.reserve(N);
      for (int i = 0; i < N; ++i) v.emplace_back(i, "Salem", 636001);
      std::cout << "checksum " << v.back().reg() << '\n'; }
    auto t1 = std::chrono::steady_clock::now();
    { std::vector<StudentP> v; v.reserve(N);
      for (int i = 0; i < N; ++i) v.emplace_back(i, "Salem", 636001);
      std::cout << "checksum " << v.back().reg() << '\n'; }
    auto t2 = std::chrono::steady_clock::now();
    std::cout << "build+destroy 1,000,000 students: member "
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms, pointer "
              << std::chrono::duration<double, std::milli>(t2 - t1).count() << " ms\n";
}
