// Task 3 - constructors/destructors in derived classes, member classes, virtual base
// Compile normally for the virtual version; add -DNOVIRT for the Task 3.4 experiment.
#include <iostream>
#include <string>

#ifdef NOVIRT
#define VIRT
#define PERSON_INIT(...)                 // non-virtual: TA may not build Person directly
#else
#define VIRT virtual
#define PERSON_INIT(...) Person(__VA_ARGS__),
#endif

class Address {                          // member class of Person
    std::string city_; int pin_;
public:
    Address(const std::string& c, int p) : city_(c), pin_(p) { std::cout << "  Address(" << city_ << ")\n"; }
    ~Address() { std::cout << "  ~Address\n"; }
};
class Course {                           // member class of Student
    std::string code_;
public:
    explicit Course(const std::string& c) : code_(c) { std::cout << "  Course(" << code_ << ")\n"; }
    ~Course() { std::cout << "  ~Course\n"; }
};

class Person {
protected:
    std::string name_; int id_; Address home_;
public:
    Person(const std::string& n, int id, const std::string& city, int pin)
        : name_(n), id_(id), home_(city, pin) { std::cout << "  Person(" << name_ << ")\n"; }
    virtual ~Person() { std::cout << "  ~Person\n"; }
};
class Student : VIRT public Person {
protected:
    std::string programme_; double cgpa_; Course course_;
public:
    Student(const std::string& n, int id, const std::string& city, int pin,
            const std::string& prog, double g, const std::string& crs)
        : Person(n, id, city, pin), programme_(prog), cgpa_(g), course_(crs)
    { std::cout << "  Student\n"; }
    ~Student() override { std::cout << "  ~Student\n"; }
};
class Staff : VIRT public Person {
protected:
    std::string dept_; double salary_;
public:
    Staff(const std::string& n, int id, const std::string& city, int pin,
          const std::string& d, double s)
        : Person(n, id, city, pin), dept_(d), salary_(s) { std::cout << "  Staff\n"; }
    ~Staff() override { std::cout << "  ~Staff\n"; }
};
class TeachingAssistant : public Student, public Staff {
public:
    TeachingAssistant(const std::string& n, int id, const std::string& city, int pin,
                      const std::string& prog, double g, const std::string& crs,
                      const std::string& d, double s)
        : PERSON_INIT(n, id, city, pin)
          Student(n, id, city, pin, prog, g, crs), Staff(n, id, city, pin, d, s)
    { std::cout << "  TeachingAssistant\n"; }
    ~TeachingAssistant() override { std::cout << "  ~TeachingAssistant\n"; }
};

int main()
{
    { std::cout << "--- Student ---\n";
      Student s("Kavya", 1, "Salem", 636001, "B.Tech", 8.7, "CS101");
      std::cout << "  [end of block]\n"; }
    { std::cout << "--- Staff ---\n";
      Staff f("Dr. Rao", 2, "Erode", 638001, "CSE", 90000);
      std::cout << "  [end of block]\n"; }
    { std::cout << "--- TeachingAssistant ---\n";
      TeachingAssistant ta("Arun", 3, "Chennai", 600001, "M.Tech", 9.1, "CS201", "CSE", 25000);
      std::cout << "  [end of block]\n"; }
    std::cout << "sizeof(TeachingAssistant) = " << sizeof(TeachingAssistant) << '\n';
}
