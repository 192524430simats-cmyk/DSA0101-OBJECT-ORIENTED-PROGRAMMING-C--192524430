// Task 4.1/4.2 - the ORIGINAL defective program, instrumented to prove each defect
#include <iostream>
#include <vector>
static int liveHistory = 0;                 // how many history arrays are currently allocated

class Account {
public:
    double rate() const { return 3.5; }
    ~Account() { std::cout << "  ~Account()\n"; }
};
class SeniorAccount : public Account {
    double* history = new double[100];
public:
    SeniorAccount() { ++liveHistory; std::cout << "  SeniorAccount(): history allocated\n"; }
    double rate() const { return 4.0; }
    ~SeniorAccount() { delete[] history; --liveHistory; std::cout << "  ~SeniorAccount(): history released\n"; }
};

int main()
{
    Account* accounts[2] = { new Account, new SeniorAccount };
    std::cout << "[defect 1] rates printed through Account*:\n";
    for (Account* a : accounts) std::cout << a->rate() << "\n";

    std::cout << "[defect 2] deleting through Account*:\n";
    for (Account* a : accounts) delete a;
    std::cout << "history arrays still allocated: " << liveHistory << "\n";

    std::cout << "[defect 3] slicing:\n";
    Account copy = SeniorAccount();         // SeniorAccount part is cut off
    std::cout << "copy.rate() = " << copy.rate() << " (a plain Account now)\n";
    std::vector<Account> v;
    v.push_back(SeniorAccount());           // same slicing inside the vector
    std::cout << "v[0].rate() = " << v[0].rate() << "\n";
}
