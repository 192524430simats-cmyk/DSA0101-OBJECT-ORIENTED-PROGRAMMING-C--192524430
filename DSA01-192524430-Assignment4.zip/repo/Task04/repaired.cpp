// Task 4.3 - repaired program: virtual functions + virtual destructor + pointers/references
#include <iostream>
static int liveHistory = 0;

class Account {
public:
    Account() = default;
    Account(const Account&) = delete;             // copying (= slicing) is not allowed
    Account& operator=(const Account&) = delete;
    virtual ~Account() { std::cout << "  ~Account()\n"; }       // virtual destructor
    virtual double rate() const { return 3.5; }                 // virtual function
};
class SeniorAccount : public Account {
    double* history = new double[100]();
public:
    SeniorAccount() { ++liveHistory; }
    double rate() const override { return 4.0; }                // override checked by compiler
    ~SeniorAccount() override { delete[] history; --liveHistory; std::cout << "  ~SeniorAccount(): history released\n"; }
};

void show(const Account& acc) { std::cout << "via reference: " << acc.rate() << "\n"; }

int main()
{
    Account* accounts[2] = { new Account, new SeniorAccount };
    for (Account* a : accounts) std::cout << a->rate() << "\n";   // 3.5 then 4
    show(*accounts[1]);                                           // reference: no copy, no slicing
    for (Account* a : accounts) delete a;                          // full destruction chain
    std::cout << "history arrays still allocated: " << liveHistory << "\n";
    // Account copy = SeniorAccount();   // now a COMPILE ERROR (copy constructor deleted)
}
