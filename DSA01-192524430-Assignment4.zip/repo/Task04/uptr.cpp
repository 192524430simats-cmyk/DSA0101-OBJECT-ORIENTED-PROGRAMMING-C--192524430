// Task 4 alternative: std::unique_ptr<Account> in a std::vector
#include <iostream>
#include <memory>
#include <vector>
class Account {
public:
    virtual ~Account() = default;
    virtual double rate() const { return 3.5; }
};
class SeniorAccount : public Account {
    std::unique_ptr<double[]> history = std::make_unique<double[]>(100);   // no manual delete[]
public:
    double rate() const override { return 4.0; }
};
int main()
{
    std::vector<std::unique_ptr<Account>> accounts;
    accounts.push_back(std::make_unique<Account>());
    accounts.push_back(std::make_unique<SeniorAccount>());
    for (const auto& a : accounts) std::cout << a->rate() << "\n";
    // no delete loop: every account (and its history) is released when the vector dies
}
